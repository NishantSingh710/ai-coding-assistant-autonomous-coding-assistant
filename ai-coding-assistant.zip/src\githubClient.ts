import { Octokit } from '@octokit/rest';
import { getGitHubConfig } from './config.js';

const config = getGitHubConfig();
export const octokit = new Octokit({
  auth: config.GITHUB_TOKEN
});

const repoRef = {
  owner: config.GITHUB_OWNER,
  repo: config.GITHUB_REPO
};

export async function getDefaultBranchSha(): Promise<string> {
  const { data } = await octokit.git.getRef({
    ...repoRef,
    ref: `heads/${config.GITHUB_BASE_BRANCH}`
  });
  return data.object.sha;
}

export async function createBranch(branch: string, sha: string): Promise<void> {
  await octokit.git.createRef({
    ...repoRef,
    ref: `refs/heads/${branch}`,
    sha
  });
}

export async function readRepoFile(path: string, ref = config.GITHUB_BASE_BRANCH): Promise<string> {
  const { data } = await octokit.repos.getContent({
    ...repoRef,
    path,
    ref
  });

  if (Array.isArray(data) || data.type !== 'file' || !('content' in data)) {
    throw new Error(`${path} is not a readable file`);
  }

  return Buffer.from(data.content, 'base64').toString('utf8');
}

export async function upsertFile(input: {
  branch: string;
  path: string;
  content: string;
  message: string;
}): Promise<void> {
  let sha: string | undefined;

  try {
    const { data } = await octokit.repos.getContent({
      ...repoRef,
      path: input.path,
      ref: input.branch
    });
    if (!Array.isArray(data) && data.type === 'file') {
      sha = data.sha;
    }
  } catch (error: unknown) {
    const status = (error as { status?: number }).status;
    if (status !== 404) throw error;
  }

  await octokit.repos.createOrUpdateFileContents({
    ...repoRef,
    path: input.path,
    branch: input.branch,
    message: input.message,
    content: Buffer.from(input.content, 'utf8').toString('base64'),
    sha
  });
}

export async function openPullRequest(input: {
  branch: string;
  title: string;
  body: string;
}): Promise<string> {
  const { data } = await octokit.pulls.create({
    ...repoRef,
    title: input.title,
    body: input.body,
    head: input.branch,
    base: config.GITHUB_BASE_BRANCH
  });

  return data.html_url;
}
