# College Project Report: AI Coding Assistant

## Project Overview
This project is an AI-powered coding assistant built with TypeScript. It can generate plans, propose code changes, and create GitHub pull requests using a local Ollama model.

## Purpose
The application demonstrates an autonomous assistant that integrates language models with GitHub actions to streamline coding tasks, such as generating implementation plans and patches.

## Technologies Used
- TypeScript
- Node.js
- pnpm
- Zod for schema validation
- Commander for CLI parsing
- dotenv for environment variable management
- GitHub REST API via `@octokit/rest`

## Project Structure
- `src/`
  - `index.ts`: Main CLI entry point with commands `plan`, `propose`, and `pr`.
  - `config.ts`: Environment schema validation and default configuration.
  - `aiClient.ts`: AI interaction logic for generating plans and edits.
  - `githubClient.ts`: GitHub repository access and PR management.
  - `webServer.ts`: Optional browser interface server.
- `dist/`: Compiled build artifacts.
- `package.json`: Project metadata, dependencies, and scripts.
- `.env.example`: Example environment variables configuration.

## Features
- Generate coding plans from a task description.
- Propose code changes based on selected repository files.
- Create GitHub branches and pull requests automatically.
- Support for local Ollama models.
- Environment-based configuration for Ollama and GitHub.

## Setup Instructions
1. Install dependencies:
   ```powershell
   pnpm install
   ```
2. Copy and configure environment variables:
   ```powershell
   Copy-Item .env.example .env
   ```
3. Update `.env` values:
   ```env
   AI_PROVIDER=ollama
   OLLAMA_BASE_URL=http://localhost:11434
   OLLAMA_MODEL=qwen2.5-coder:7b
   GITHUB_TOKEN=github_pat_...
   GITHUB_OWNER=your-org-or-user
   GITHUB_REPO=your-repo
   GITHUB_BASE_BRANCH=main
   ```
4. Build the project:
   ```powershell
   pnpm build
   ```

## Running the Application
### CLI
- Show help:
  ```powershell
  node dist/index.js --help
  ```
- Generate a plan:
  ```powershell
  node dist/index.js plan "Add input validation to login"
  ```
- Propose code changes:
  ```powershell
  node dist/index.js propose "Fix login validation" --files src/login.ts src/config.ts
  ```
- Create a PR:
  ```powershell
  node dist/index.js pr "Add login validation" --files src/login.ts
  ```

### Browser UI (optional)
- Build and run the web interface:
  ```powershell
  pnpm run build
  pnpm run web
  ```
- Visit `http://localhost:5173`

## Key Configurations
- `AI_PROVIDER`: `ollama`
- `OLLAMA_BASE_URL`: Local Ollama service URL
- `OLLAMA_MODEL`: Local model name, e.g. `qwen2.5-coder:7b`

## Security Considerations
- Do not commit `.env` or API keys to source control.
- Use a fine-grained GitHub token with minimal required permissions.
- Validate all environment variables before using the application.

## Conclusion
This project provides a practical example of integrating AI-assisted development workflows into a CLI-based tool. It demonstrates how to use TypeScript, Ollama, and GitHub APIs together in a real-world automation scenario.
