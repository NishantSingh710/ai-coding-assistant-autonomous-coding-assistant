$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$NodeDir = 'C:\Users\n7230\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin'
$env:Path = "$NodeDir;$env:Path"
Set-Location $ProjectDir
& "$NodeDir\node.exe" '.\node_modules\typescript\bin\tsc'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& "$NodeDir\node.exe" '.\dist\webServer.js'
