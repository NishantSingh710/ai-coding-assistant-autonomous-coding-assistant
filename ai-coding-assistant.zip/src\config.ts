import 'dotenv/config';
import { z } from 'zod';

const AiConfigSchema = z
  .object({
    AI_PROVIDER: z.literal('ollama').default('ollama'),
    OLLAMA_BASE_URL: z.string().url().default('http://localhost:11434'),
    OLLAMA_MODEL: z.string().default('qwen2.5-coder:7b')
  });

const GitHubConfigSchema = z.object({
  GITHUB_TOKEN: z.string().min(1, 'GITHUB_TOKEN is required'),
  GITHUB_OWNER: z.string().min(1, 'GITHUB_OWNER is required'),
  GITHUB_REPO: z.string().min(1, 'GITHUB_REPO is required'),
  GITHUB_BASE_BRANCH: z.string().default('main')
});

export function getAiConfig() {
  return AiConfigSchema.parse(process.env);
}

export function getGitHubConfig() {
  return GitHubConfigSchema.parse(process.env);
}
