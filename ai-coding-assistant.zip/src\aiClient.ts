import { getAiConfig } from './config.js';

type FileEdit = { path: string; content: string };

export async function generateCodingPlan(task: string): Promise<string> {
  return completeText({
    system:
      'You are a senior software engineer. Produce a concise implementation plan, risks, and verification steps.',
    user: task
  });
}

export async function generateFileEdits(input: {
  task: string;
  files: Array<{ path: string; content: string }>;
}): Promise<FileEdit[]> {
  const raw = await completeText({
    system:
      'Return only JSON in this shape: {"files":[{"path":"relative/path.ts","content":"full file content"}]}. Include full replacement contents for changed files only.',
    user: JSON.stringify(input),
    json: true
  });

  const parsed = JSON.parse(extractJson(raw)) as { files?: FileEdit[] };
  return parsed.files ?? [];
}

async function completeText(input: {
  system: string;
  user: string;
  json?: boolean;
}): Promise<string> {
  const config = getAiConfig();

  let response: Response;
  try {
    response = await fetch(`${config.OLLAMA_BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: config.OLLAMA_MODEL,
        stream: false,
        format: input.json ? 'json' : undefined,
        messages: [
          { role: 'system', content: input.system },
          { role: 'user', content: input.user }
        ]
      })
    });
  } catch (error) {
    throw new Error(
      `Could not reach Ollama at ${config.OLLAMA_BASE_URL}. Start Ollama and pull the model with: ollama pull ${config.OLLAMA_MODEL}`,
      { cause: error }
    );
  }

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Ollama request failed (${response.status}): ${body}`);
  }

  const data = (await response.json()) as { message?: { content?: string } };
  return data.message?.content ?? '';
}

function extractJson(value: string): string {
  const trimmed = value.trim();
  if (trimmed.startsWith('{')) return trimmed;

  const match = trimmed.match(/\{[\s\S]*\}/);
  if (!match) {
    throw new Error(`Model did not return JSON: ${value}`);
  }

  return match[0];
}
