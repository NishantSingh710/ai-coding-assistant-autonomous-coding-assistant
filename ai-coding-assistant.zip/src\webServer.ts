﻿import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { generateCodingPlan } from './aiClient.js';

const port = Number(process.env.AGENT_WEB_PORT ?? 5173);
const webRoot = join(process.cwd(), 'web');

const mimeTypes: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8'
};

const server = createServer(async (request, response) => {
  try {
    if (!request.url) {
      sendJson(response, 400, { error: 'Missing request URL' });
      return;
    }

    const url = new URL(request.url, `http://${request.headers.host ?? 'localhost'}`);

    if (request.method === 'POST' && url.pathname === '/api/plan') {
      const body = await readJsonBody<{ task?: string }>(request);
      const task = body.task?.trim();
      if (!task) {
        sendJson(response, 400, { error: 'Task is required' });
        return;
      }

      const result = await generateCodingPlan(task);
      sendJson(response, 200, { result });
      return;
    }

    if (request.method !== 'GET') {
      sendJson(response, 405, { error: 'Method not allowed' });
      return;
    }

    const pathname = url.pathname === '/' ? '/index.html' : url.pathname;
    const filePath = normalize(join(webRoot, pathname));
    if (!filePath.startsWith(webRoot)) {
      sendJson(response, 403, { error: 'Forbidden' });
      return;
    }

    const data = await readFile(filePath);
    response.writeHead(200, {
      'Content-Type': mimeTypes[extname(filePath)] ?? 'application/octet-stream'
    });
    response.end(data);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    sendJson(response, 500, { error: message });
  }
});

server.listen(port, () => {
  console.log(`AI agent view running at http://localhost:${port}`);
});

function sendJson(response: import('node:http').ServerResponse, status: number, value: unknown) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(value));
}

async function readJsonBody<T>(request: import('node:http').IncomingMessage): Promise<T> {
  const chunks: Buffer[] = [];
  for await (const chunk of request) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }

  const raw = Buffer.concat(chunks).toString('utf8');
  return raw ? (JSON.parse(raw) as T) : ({} as T);
}
