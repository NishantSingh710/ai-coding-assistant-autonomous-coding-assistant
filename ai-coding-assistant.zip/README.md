﻿AI Coding Assistant (Ollama-only)

A lightweight TypeScript CLI and local web UI that uses a local Ollama model to generate coding plans and file edits, and can create GitHub pull requests.

## Quick start

Prerequisites
- Node.js (16+)
- Ollama running locally with the model you want available

Install & build

```powershell
npm install
npm run build
```

Run the web UI (one-click on Windows)

- Double-click `start-web.bat` in the project root (builds and launches the server)
- Or run the server manually and open the UI:

```powershell
node dist/webServer.js
# Open http://localhost:5173/open.html in your browser
```

CLI usage

```powershell
# Show commands
node dist/index.js --help

# Generate a plan
node dist/index.js plan "Describe the task"

# Propose edits (provide file paths to include as context)
node dist/index.js propose "Refactor X" -f path/to/file1 path/to/file2

# Create a pull request (requires GITHUB_* env vars)
node dist/index.js pr "Implement feature" -f path/to/file1 path/to/file2
```

Configuration (environment variables)

Create a `.env` file from `.env.example` and fill values:

- `AI_PROVIDER` — must be `ollama`
- `OLLAMA_BASE_URL` — e.g. `http://localhost:11434`
- `OLLAMA_MODEL` — e.g. `qwen2.5-coder:7b`
- `AGENT_WEB_PORT` — optional, default 5173
- `GITHUB_TOKEN` — Personal Access Token (only when using PR functionality)
- `GITHUB_OWNER`, `GITHUB_REPO`, `GITHUB_BASE_BRANCH`

Security
- Never commit secrets. Keep `.env` in `.gitignore`; share only `.env.example`.
- If a token is leaked, revoke and rotate it immediately in GitHub settings.

Sharing the project
- Recommended: push to GitHub and create a Release. Remove secrets before pushing.
- Simple distribution: remove `node_modules`, zip the folder and share.
- Portable deployment: build a Docker image (see `Dockerfile` example in docs if needed).

Development notes
- The app UI is in `web/` and served by `src/webServer.ts`.
- AI calls use the local Ollama chat endpoint in `src/aiClient.ts`.
- GitHub integration is handled in `src/githubClient.ts`.

Need help?
- Tell me if you want a `--dry-run` mode for `pr`, a `Dockerfile`, or a release ZIP and I will prepare it.
# AI Coding Assistant

A small TypeScript starter for an autonomous coding assistant that uses a local Ollama model with GitHub API actions.

## Ollama Setup

Install Ollama from https://ollama.com, then pull a coding model:

```powershell
ollama pull qwen2.5-coder:7b
ollama serve
```

If Ollama is already running, `ollama serve` may say the port is in use. That is fine.

## Setup

```powershell
pnpm install
Copy-Item .env.example .env
```

Fill in `.env`:

```env
AI_PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5-coder:7b
GITHUB_TOKEN=github_pat_...
GITHUB_OWNER=your-org-or-user
GITHUB_REPO=your-repo
GITHUB_BASE_BRANCH=main
```

Use a fine-grained GitHub token with the minimum permissions your workflow needs, usually `Contents: read/write` and `Pull requests: read/write`.


## Browser View

Run the React input/result view on Windows:\r\n\r\n```powershell\r\n.\start-web.ps1\r\n```\r\n\r\nOr double-click `start-web.bat`. If `pnpm` is installed globally, this also works:\r\n\r\n```powershell\r\npnpm run build\r\npnpm run web\r\n```

Open:

```text
http://localhost:5173
```

The page has a task input field and a result view. It calls the same local Ollama agent used by the CLI.
## Commands

Generate a plan and patch proposal without touching GitHub:

```powershell
pnpm dev -- plan "Add input validation to the login endpoint"
```

Read files from GitHub and ask the model for a patch:

```powershell
pnpm dev -- propose "Fix the bug in auth middleware" --files src/auth.ts src/server.ts
```

Create a branch, commit generated files, and open a PR:

```powershell
pnpm dev -- pr "Add a health check endpoint" --files src/server.ts
```

The `pr` command writes the model output to files exactly as returned, so start with small, low-risk tasks and inspect the PR carefully.


