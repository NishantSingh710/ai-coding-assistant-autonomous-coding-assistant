s@echo off
set PROJECT_DIR=%~dp0
set NODE_PATH=C:\Users\n7230\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin
set PATH=%NODE_PATH%;%PATH%
cd /d "%PROJECT_DIR%"
"C:\Users\n7230\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" ".\node_modules\typescript\bin\tsc"
if errorlevel 1 pause && exit /b %errorlevel%
"C:\Users\n7230\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" ".\dist\webServer.js"
